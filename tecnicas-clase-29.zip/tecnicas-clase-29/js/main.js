//Ejemplos de DOM
document.getElementById("caja1").innerText = "Hola Mundo!";
document.getElementById("caja1").style = "color:red; background-color: green";

let caja2 = document.getElementById("caja2");
caja2.innerHTML = "Hola a todos!";
caja2.style = "color: white; background-color: blue; text-align: center";